<?php 
$nombre = $_POST['nombre'];
$conn = new mysqli('localhost', 'root', '', 'esquema');
$result = $conn->query("SELECT id,Nombre,Genero,Profesion,Pais,fecha FROM tabla_clientes WHERE Nombre LIKE '%$nombre%'");

while ($row = $result->fetch_assoc()) { ?>
<tr>
    <th scope="row"><?php echo $row['id']; ?></th>
    <td><?php echo $row['Nombre']; ?></td>
    <td><?php echo $row['Genero']; ?></td>
    <td><?php echo $row['Profesion']; ?></td>
    <td><?php echo $row['Pais']; ?></td>
    <td><?php echo $row['fecha']; ?></td>
</tr>
<?php 
}
?>