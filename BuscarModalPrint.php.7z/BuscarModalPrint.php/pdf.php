<?php
header('Content-Type: text/html; charset=utf-8');
require 'fpdf/fpdf.php';

$pdf = new FPDF();
$pdf->AddPage();

// Agregar logo
// Obtener el ancho de la página
$anchoPagina = $pdf->GetPageWidth();

// Obtener el ancho de la imagen
$anchoImagen = 25;

// Calcular la posición X centrada
$posicionX = ($anchoPagina - $anchoImagen) / 2;

// Insertar la imagen centrada
$pdf->Image('logo.png', $posicionX, 5, $anchoImagen, 0);

// Agregar título
$pdf->SetFont('Arial','B',20);
$pdf->Cell(0, 50, iconv('UTF-8', 'ISO-8859-1', 'Resultado de la búsqueda es:'), 0, 1, 'C');

// Agregar tabla
$pdf->SetFont('Arial','B',16);
$pdf->SetFillColor(255,255,255);
$pdf->SetTextColor(0);
$pdf->SetDrawColor(0,0,0);
$pdf->Cell(30,10,'ID',1,0,'C',true);
$pdf->Cell(30,10,'Nombre',1,0,'C',true); 
$pdf->Cell(30,10,'Genero',1,0,'C',true);
$pdf->Cell(30,10,'Profesion',1,0,'C',true);
$pdf->Cell(30,10,'Pais',1,0,'C',true); 
$pdf->Cell(30,10,'Fecha',1,1,'C',true);

$nombre = $_GET['nombre'];
$conn = new mysqli('localhost', 'root', '', 'esquema');
$result = $conn->query("SELECT * FROM tabla_clientes WHERE Nombre LIKE '%$nombre%'");

while ($row = $result->fetch_assoc()) {
  $pdf->SetFont('Arial','',9);
  $pdf->SetFillColor(255,255,255);
  $pdf->SetTextColor(0);
  $pdf->SetDrawColor(0,0,0);
  $pdf->Cell(30,10,$row['id'],1,0,'C',true);   
  $pdf->Cell(30,10,$row['Nombre'],1,0,'C',true);
  $pdf->Cell(30,10,$row['Genero'],1,0,'C',true);
  $pdf->Cell(30,10,$row['Profesion'],1,0,'C',true);
  $pdf->Cell(30,10,$row['Pais'],1,0,'C',true);
  $pdf->Cell(30,10,$row['fecha'],1,1,'C',true);  
} 

$pdf->Output();

?>